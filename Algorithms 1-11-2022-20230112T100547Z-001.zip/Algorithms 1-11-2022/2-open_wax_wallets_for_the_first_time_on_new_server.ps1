Write-Host 'Hello, the script is running, please wait..'
$Number_of_profiles=(Get-Content .\outlook_accounts.txt | Where-Object { $_.Trim() -ne '' }).count
Clear-Content .\users_wax_wallets.txt
taskkill /IM "rdpclip.exe" /F | Out-Null
while($Number_of_profiles -ne 0)
{
$profile_name=gc outlook_accounts.txt | select -last $Number_of_profiles | select -first 1
$app = Start-Process -FilePath "${Env:ProgramFiles}\Google\Chrome\Application\chrome.exe" -WindowStyle Maximized  -ArgumentList '--app=https://wallet.wax.io/', --profile-directory=$profile_name -PassThru
Start-Sleep -Seconds 23
$iter=0
While ($iter -ne 11){
           .\press_tab.exe | Out-Null
           $iter++
                     }
gc outlook_accounts.txt | select -last $Number_of_profiles | select -first 1 | clip
.\ctrl_v.exe | Out-Null
Start-Sleep -Seconds 2
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 2
cat .\password.txt | clip
.\ctrl_v.exe | Out-Null
Start-Sleep -Seconds 2
.\press_tab.exe | Out-Null
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 1
.\enter.exe | Out-Null
Start-Sleep -Seconds 12
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 2
.\space.exe | Out-Null
.\press_tab.exe | Out-Null
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 2
.\space.exe | Out-Null
Start-Sleep -Seconds 2
.\enter.exe | Out-Null
Start-Sleep -Seconds 1
.\click_on_save.exe | Out-Null
Start-Sleep -Seconds 15
.\fully_page_down_with_two_clicks.exe | Out-Null
Start-Sleep -Seconds 4
.\click_on_copy_user.exe | Out-Null
Start-Sleep -Seconds 4
$profile_name | out-file -filepath .\users_wax_wallets.txt -append
$current_wax_wallet_user_name=Get-Clipboard
$current_wax_wallet_user_name | out-file -filepath .\users_wax_wallets.txt -append
.\ctrl_w.exe | Out-Null
$Number_of_profiles--
}

$Number_of_profiles=(Get-Content .\outlook_accounts.txt | Where-Object { $_.Trim() -ne '' }).count
$number_of_wams=(Get-Content -path .\users_wax_wallets.txt | Select-String "wam").count
if ($number_of_wams -eq $Number_of_profiles)
{
  $temp = Get-Content -path .\users_wax_wallets.txt | Select-String "wam"
  Write-Output $temp | Set-Content -Path .\users_wax_wallets.txt
}
((Get-Content -path .\users_wax_wallets.txt -Raw) -replace 'DOT','.') | Set-Content -Path .\users_wax_wallets.txt

C:\Windows\System32\rdpclip.exe









