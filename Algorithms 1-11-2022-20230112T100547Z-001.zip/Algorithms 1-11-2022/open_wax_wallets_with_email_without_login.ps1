Write-Host 'Hello, the script is running, please wait..'
$Number_of_profiles=(Get-Content .\outlook_accounts.txt | Where-Object { $_.Trim() -ne '' }).count
Clear-Content .\users_wax_wallets.txt
taskkill /IM "rdpclip.exe" /F | Out-Null
while($Number_of_profiles -ne 0)
{
$profile_name=gc outlook_accounts.txt | select -last $Number_of_profiles | select -first 1
$app = Start-Process -FilePath "${Env:ProgramFiles}\Google\Chrome\Application\chrome.exe" -WindowStyle Maximized  -ArgumentList '--app=https://wallet.wax.io/', --profile-directory=$profile_name -PassThru
Start-Sleep -Seconds 23
$iter=0
While ($iter -ne 11){
           .\press_tab.exe | Out-Null
           $iter++
                     }
gc outlook_accounts.txt | select -last $Number_of_profiles | select -first 1 | clip
.\ctrl_v.exe | Out-Null
Start-Sleep -Seconds 2
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 2
cat .\password.txt | clip
.\ctrl_v.exe | Out-Null
Start-Sleep -Seconds 2

$Number_of_profiles--
}


C:\Windows\System32\rdpclip.exe









