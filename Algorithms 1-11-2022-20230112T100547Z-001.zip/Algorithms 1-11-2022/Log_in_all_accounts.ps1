Write-Host 'Hello, the script is running, please wait..'
Stop-Process -Name "chrome" -Force
Start-Sleep -Seconds 15
.\log_in_day_accounts.ps1 | Out-Null
Start-Sleep -Seconds 3
.\log_in_night_accounts.ps1 | Out-Null
Start-Sleep -Seconds 3







