Write-Host 'Hello, the script is running, please wait..'
$Number_of_profiles=(Get-Content .\outlook_accounts.txt | Where-Object { $_.Trim() -ne '' }).count
taskkill /IM "rdpclip.exe" /F | Out-Null
while($Number_of_profiles -ne 0)
{
$profile_name=gc outlook_accounts.txt | select -last $Number_of_profiles | select -first 1
$app = Start-Process -FilePath "${Env:ProgramFiles}\Google\Chrome\Application\chrome.exe" -WindowStyle Maximized  -ArgumentList '--app=chrome://settings/content/popups', --profile-directory=$profile_name -PassThru
start-sleep -seconds 6
.\click_on_url.exe | Out-Null
cat .\link_alienworlds.txt | clip
.\ctrl_v.exe | Out-Null
.\enter.exe | Out-Null
Start-Sleep -Seconds 15
.\press_play_game_regular_chrome_window.exe | Out-Null
Start-Sleep -Seconds 17
.\press_tab.exe | Out-Null
gc random_names.txt | select -last $Number_of_profiles | select -first 1 | clip
.\ctrl_v.exe | Out-Null
Start-Sleep -Seconds 3
.\press_tab.exe | Out-Null
gc outlook_accounts.txt | select -last $Number_of_profiles | select -first 1 | clip
Start-Sleep -Seconds 2
.\ctrl_v.exe | Out-Null
Start-Sleep -Seconds 1
.\press_tab.exe | Out-Null
.\space.exe | Out-Null
Start-Sleep -Seconds 1
.\press_tab.exe | Out-Null
.\space.exe | Out-Null
Start-Sleep -Seconds 1
.\chrome_page_down.exe | Out-Null
Start-Sleep -Seconds 1
.\press_ready.exe | Out-Null
Start-Sleep -Seconds 8
.\press_tab.exe | Out-Null
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 1
.\press_tab.exe | Out-Null
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 1
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 1
.\space.exe | Out-Null
Start-Sleep -Seconds 1
.\chrome_page_down.exe | Out-Null
Start-Sleep -Seconds 1
.\click_on_mine_planet.exe | Out-Null
Start-Sleep -Seconds 15
cat .\x_coordinates.txt | clip
Start-Sleep -Seconds 1
.\22_click_on_page_down.exe | Out-Null
Start-Sleep -Seconds 1
.\click_on_x_coordinate.exe | Out-Null
Start-Sleep -Seconds 2
.\ctrl_v.exe | Out-Null
Start-Sleep -Seconds 1
cat .\y_coordinates.txt | clip
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 2
.\ctrl_v.exe | Out-Null
Start-Sleep -Seconds 2
.\press_on_the_land.exe | Out-Null
Start-Sleep -Seconds 12
.\press_tab.exe | Out-Null
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 3
.\enter.exe | Out-Null
Start-Sleep -Seconds 6
$Number_of_profiles--
}
Start-Sleep -Seconds 20
Stop-Process -Name "chrome"
C:\Windows\System32\rdpclip.exe








