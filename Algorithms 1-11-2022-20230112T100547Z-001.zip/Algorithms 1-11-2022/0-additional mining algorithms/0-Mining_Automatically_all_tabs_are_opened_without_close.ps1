Write-Host 'Hello, The script is running, please press alt+1 twice'
Set-ItemProperty -Path "HKCU:\Console" -Name "QuickEdit" -Value 0
Set-ItemProperty -Path "HKCU:\Console" -Name "InsertMode" -Value 0
Start-Sleep -Seconds 15
$Number_of_profiles=(Get-Content .\outlook_accounts.txt | Where-Object { $_.Trim() -ne '' }).count
$counter=0
$iter=0
$number_of_pages=5
While ($true)
{
       .\click_on_mine_regular_chrome_window.exe | Out-Null
       start-sleep -seconds 34
       .\click_on_mine_regular_chrome_window.exe | Out-Null
       Start-Sleep -Seconds 14
       .\press_tab.exe | Out-Null
       .\press_tab.exe | Out-Null
       Start-Sleep -Seconds 0.5
       .\enter.exe | Out-Null
       Start-Sleep -Seconds 0.5
       .\click_on_exit_regular_chrome_window.exe | Out-Null
       start-sleep -seconds 0.5
       .\alt_tab_and_left_twice.exe | Out-Null
       start-sleep -seconds 0.5
}
