Write-Host 'Hello, The script is running, please press alt+1 twice'
Set-ItemProperty -Path "HKCU:\Console" -Name "QuickEdit" -Value 0
Set-ItemProperty -Path "HKCU:\Console" -Name "InsertMode" -Value 0
Start-Sleep -Seconds 15
$Number_of_profiles=(Get-Content .\outlook_accounts.txt | Where-Object { $_.Trim() -ne '' }).count
 $counter=0
$iter=0
$min = Get-Date '12:01'
$max = Get-Date '23:59'
$number_of_pages=5
$number_of_iterations=120
While ($true)
{
  $profile=$Number_of_profiles
  While ($profile -ne 0)
  {

   $now = Get-Date
   if ($min.TimeOfDay -le $now.TimeOfDay -and $max.TimeOfDay -ge $now.TimeOfDay) 
   {
     Stop-Process -Name "chrome" -Force
     $counter=0
     Start-Sleep -Seconds 2
     Write-Host 'Night Mining!!'
     Start-Sleep -Seconds 1
     .\0-Night_Mining.ps1 | Out-Null
     break
   }

   $counter++
   $profile_name=gc outlook_accounts.txt | select -last $profile | select -first 1
   $profile--
   $app = Start-Process -FilePath "${Env:ProgramFiles}\Google\Chrome\Application\chrome.exe" -WindowStyle Maximized  -ArgumentList '--app=chrome://settings/content/popups', --profile-directory=$profile_name -PassThru
   start-sleep -seconds 5
   .\click_on_url.exe | Out-Null
   cat .\link_alienworlds.txt | clip
   .\ctrl_v.exe | Out-Null
   start-sleep -seconds 1
   .\enter.exe | Out-Null
   start-sleep -seconds 2
   .\click_on_exit_restore_chrome.exe | Out-Null
   start-sleep -seconds 1


   if ($counter -eq $number_of_pages)
   {
     $iter=0
     while ($iter -ne $number_of_pages)
     {

       $now = Get-Date
       if ($min.TimeOfDay -le $now.TimeOfDay -and $max.TimeOfDay -ge $now.TimeOfDay)
       {
        Stop-Process -Name "chrome" -Force
        $counter=0
        break
       }

       .\alt_tab_and_left_twice.exe | Out-Null
       start-sleep -seconds 1
       .\press_play_game_regular_chrome_window.exe | Out-Null
       $iter++
       start-sleep -seconds 10
     }
   }

   if ($counter -eq $number_of_pages)
   {
     $iter=0
     while ($iter -ne $number_of_iterations)
     {

       $now = Get-Date
       if ($min.TimeOfDay -le $now.TimeOfDay -and $max.TimeOfDay -ge $now.TimeOfDay)
       {
        Stop-Process -Name "chrome" -Force
        $counter=0
        break
       }

       .\click_on_mine_regular_chrome_window.exe | Out-Null
       start-sleep -seconds 34
       .\click_on_mine_regular_chrome_window.exe | Out-Null
       Start-Sleep -Seconds 14
       .\press_tab.exe | Out-Null
       .\press_tab.exe | Out-Null
       Start-Sleep -Seconds 0.5
       .\enter.exe | Out-Null
       Start-Sleep -Seconds 1
       .\click_on_exit_regular_chrome_window.exe | Out-Null
       start-sleep -seconds 0.5
       .\alt_tab_and_left_twice.exe | Out-Null
       start-sleep -seconds 0.5
       $iter++
     }
   }

   if ($counter -eq $number_of_pages)
   {

     $counter=0
     Stop-Process -Name "chrome" -Force
     Start-Sleep -Seconds 3
   }

  }

}
