Write-Host 'Hello, the script is running, please wait..'
Start-Sleep -Seconds 2
Start-Process "ms-settings:defaultapps"
Start-Sleep -Seconds 5
.\press_tab.exe | Out-Null
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 1
.\press_tab.exe | Out-Null
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 1
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 1
.\enter.exe | Out-Null
Start-Sleep -Seconds 1
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 1
.\enter.exe | Out-Null




