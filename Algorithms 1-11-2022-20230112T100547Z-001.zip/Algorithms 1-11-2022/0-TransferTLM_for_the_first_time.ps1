Write-Host 'Hello, the script is running, please wait..'
Start-Sleep -Seconds 15
.\5-open_alcor_for_the_first_time.ps1 | Out-Null
Start-Sleep -Seconds 3
.\0-TransferTLM.ps1 | Out-Null