Write-Host 'Hello, the script is running, please wait..'
Start-Sleep -Seconds 15
.\allow_popup_for_all_profiles.ps1 | Out-Null
Start-Sleep -Seconds 3
.\4-Open_alien_worlds_for_the_first_time_Neri.ps1 | Out-Null
Start-Sleep -Seconds 3
.\7-equip_tools_bar_opened.ps1 | Out-Null
Start-Sleep -Seconds 3







