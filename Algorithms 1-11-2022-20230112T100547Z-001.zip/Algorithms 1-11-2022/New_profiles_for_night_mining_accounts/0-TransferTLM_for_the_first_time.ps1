Write-Host 'Hello, the script is running, please wait..'
$Number_of_profiles=(Get-Content .\outlook_accounts.txt | Where-Object { $_.Trim() -ne '' }).count
taskkill /IM "rdpclip.exe" /F | Out-Null
while($Number_of_profiles -ne 0)
{
$profile_name=gc outlook_accounts.txt | select -last $Number_of_profiles | select -first 1
$app = Start-Process -FilePath "${Env:ProgramFiles}\Google\Chrome\Application\chrome.exe" -WindowStyle Maximized  -ArgumentList '--app=chrome://settings/content/popups', --profile-directory=$profile_name -PassThru
start-sleep -seconds 7
.\click_on_url.exe | Out-Null
cat .\link_alcor_wallet.txt | clip
.\ctrl_v.exe | Out-Null
start-sleep -seconds 1
.\enter.exe | Out-Null
start-sleep -seconds 3
.\exit_chrome_restore_window.exe | Out-Null
Start-Sleep -Seconds 20
.\press_on_connect_wallet_alcor.exe | Out-Null
Start-Sleep -Seconds 9
.\choose_wax_cloud_wallet.exe | Out-Null
Start-Sleep -Seconds 9
.\press_tab.exe | Out-Null
.\space.exe | Out-Null
Start-Sleep -Seconds 2
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 2
.\enter.exe | Out-Null
Start-Sleep -Seconds 12
.\click_on_transfer.exe | Out-Null
Start-Sleep -Seconds 8
.\press_tab.exe | Out-Null
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 1
.\press_tab.exe | Out-Null
.\press_tab.exe | Out-Null
cat .\wax_account.txt | clip
Start-Sleep -Seconds 2
.\ctrl_v.exe | Out-Null
Start-Sleep -Seconds 1
.\click_on_tlm_balance.exe | Out-Null
Start-Sleep -Seconds 3
.\click_on_transfer_tlm_to.exe | Out-Null
Start-Sleep -Seconds 7
.\mouse_click_to_avoid_high_cpu.exe | Out-Null
Start-Sleep -Seconds 8
.\press_tab.exe | Out-Null
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 2
.\enter.exe | Out-Null
Start-Sleep -Seconds 7
.\ctrl_w.exe | Out-Null
Start-Sleep -Seconds 4
if ($app.Id) {
    .\ctrl_w.exe | Out-Null }

$Number_of_profiles--
}

C:\Windows\System32\rdpclip.exe










