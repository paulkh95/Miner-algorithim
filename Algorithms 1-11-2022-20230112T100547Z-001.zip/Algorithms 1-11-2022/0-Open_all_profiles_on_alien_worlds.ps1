Write-Host 'Hello, the script is running, please wait..'
$Number_of_profiles=(Get-Content .\outlook_accounts.txt | Where-Object { $_.Trim() -ne '' }).count
Set-ItemProperty -Path "HKCU:\Console" -Name "QuickEdit" -Value 0
Set-ItemProperty -Path "HKCU:\Console" -Name "InsertMode" -Value 0
taskkill /IM "rdpclip.exe" /F | Out-Null
while($Number_of_profiles -ne 0)
{
$profile_name=gc outlook_accounts.txt | select -last $Number_of_profiles | select -first 1
$app = Start-Process -FilePath "${Env:ProgramFiles}\Google\Chrome\Application\chrome.exe" -WindowStyle Maximized  -ArgumentList '--app=chrome://settings/content/popups', --profile-directory=$profile_name -PassThru
start-sleep -seconds 6
.\click_on_url.exe | Out-Null
cat .\link_alienworlds.txt | clip
.\ctrl_v.exe | Out-Null
.\enter.exe | Out-Null
Start-Sleep -Seconds 10
.\press_play_game_regular_chrome_window.exe | Out-Null
Start-Sleep -Seconds 1
$Number_of_profiles--
}

C:\Windows\System32\rdpclip.exe










