Write-Host 'Hello, the script is running, please wait..'
$Number_of_profiles=(Get-Content .\outlook_accounts.txt | Where-Object { $_.Trim() -ne '' }).count
Start-Sleep -Seconds 15
while($Number_of_profiles -ne 0)
{
$profile_name=gc outlook_accounts.txt | select -last $Number_of_profiles | select -first 1
$app = Start-Process -FilePath "${Env:ProgramFiles}\Google\Chrome\Application\chrome.exe" -WindowStyle Maximized  -ArgumentList '--app=https://wallet.wax.io/', --profile-directory=$profile_name -PassThru
Start-Sleep -Seconds 7
.\large_window.exe | Out-Null
Start-Sleep -Seconds 1
$iter=0
While ($iter -ne 11){
           .\press_tab.exe | Out-Null
           $iter++
                     }
gc outlook_accounts.txt | select -last $Number_of_profiles | select -first 1 | clip
.\ctrl_v.exe | Out-Null
Start-Sleep -Seconds 1
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 1
cat .\password.txt | clip
.\ctrl_v.exe | Out-Null
Start-Sleep -Seconds 1
.\press_tab.exe | Out-Null
.\press_tab.exe | Out-Null
Start-Sleep -Seconds 1
.\enter.exe | Out-Null
Start-Sleep -Seconds 13
.\alt_tab.exe | Out-Null
Start-Sleep -Seconds 1
.\open_last_email.exe | Out-Null
Start-Sleep -Seconds 1
.\double_click_on_the_pin.exe | Out-Null
Start-Sleep -Seconds 1
.\ctrl_c.exe | Out-Null
Start-Sleep -Seconds 1
.\click_on_back.exe | Out-Null
Start-Sleep -Seconds 2
.\alt_tab.exe | Out-Null
Start-Sleep -Seconds 1
.\click_on_the_pin_box.exe | Out-Null
Start-Sleep -Seconds 1
.\ctrl_v.exe | Out-Null
Start-Sleep -Seconds 1
.\enter.exe | Out-Null
Start-Sleep -Seconds 3
.\ctrl_w.exe | Out-Null
$Number_of_profiles--
}
