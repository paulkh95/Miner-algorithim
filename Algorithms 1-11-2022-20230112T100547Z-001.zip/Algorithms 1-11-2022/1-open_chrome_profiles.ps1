Write-Host 'Hello, the script is running, please wait...'
$Number_of_profiles=(Get-Content .\outlook_accounts.txt | Where-Object { $_.Trim() -ne '' }).count
Write-Host 'Buliding'
Write-Output $Number_of_profiles
Write-Host 'Profile'
Start-Sleep -Seconds 5
taskkill /IM "rdpclip.exe" /F | Out-Null
while($Number_of_profiles -ne 0)
{
$profile_name=gc outlook_accounts.txt | select -last $Number_of_profiles | select -first 1
$app = Start-Process -FilePath "${Env:ProgramFiles}\Google\Chrome\Application\chrome.exe" -ArgumentList --profile-directory=$profile_name -PassThru
Start-Sleep -Seconds 7
.\ctrl_w.exe | Out-Null
$Number_of_profiles--
$time=7*$Number_of_profiles
write-host "please wait $($time) seconds.."
}

C:\Windows\System32\rdpclip.exe













