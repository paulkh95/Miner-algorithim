Write-Host 'Hello, the script is running, please wait..'
$Number_of_profiles=(Get-Content .\outlook_accounts.txt | Where-Object { $_.Trim() -ne '' }).count
taskkill /IM "rdpclip.exe" /F | Out-Null
while($Number_of_profiles -ne 0)
{
$profile_name=gc outlook_accounts.txt | select -last $Number_of_profiles | select -first 1
$app = Start-Process -FilePath "${Env:ProgramFiles}\Google\Chrome\Application\chrome.exe" -WindowStyle Maximized  -ArgumentList '--app=https://wallet.wax.io/', --profile-directory=$profile_name -PassThru
Start-Sleep -Seconds 5
$Number_of_profiles--
}
C:\Windows\System32\rdpclip.exe