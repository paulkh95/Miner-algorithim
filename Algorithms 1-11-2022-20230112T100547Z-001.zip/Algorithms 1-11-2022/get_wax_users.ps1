Write-Host 'Hello, the script is running, please wait..'
$Number_of_profiles=(Get-Content .\outlook_accounts.txt | Where-Object { $_.Trim() -ne '' }).count
Clear-Content .\users_wax_wallets.txt
taskkill /IM "rdpclip.exe" /F | Out-Null
while($Number_of_profiles -ne 0)
{
$profile_name=gc outlook_accounts.txt | select -last $Number_of_profiles | select -first 1
$app = Start-Process -FilePath "${Env:ProgramFiles}\Google\Chrome\Application\chrome.exe" -WindowStyle Maximized  -ArgumentList '--app=https://wallet.wax.io/', --profile-directory=$profile_name -PassThru
Start-Sleep -Seconds 25
.\click_on_logo.exe | Out-Null
Start-Sleep -Seconds 4
.\triple_click_on_wax_wallet_user_name.exe | Out-Null
Start-Sleep -Seconds 4
.\ctrl_c.exe | Out-Null
$profile_name | out-file -filepath .\users_wax_wallets.txt -append
$current_wax_wallet_user_name=Get-Clipboard
$current_wax_wallet_user_name | out-file -filepath .\users_wax_wallets.txt -append
.\ctrl_w.exe | Out-Null
$Number_of_profiles--
}


C:\Windows\System32\rdpclip.exe









